#!/sbin/sh
# ------------------------------
# ThundeRStormS KERNEL INSTALLER
# Created by @djb77
#
# Credit also goes to @Tkkg1994,
# @lyapota, @Morogoku and 
# @dwander for bits of code
# ------------------------------


# Variables
TEMP=/tmp/tstemp
TS=/data/media/0/TSkernel
BUILDPROP=/system/build.prop

## System Patches
echo "Fixing permissions for patched files..."
echo "Fixing permissions for patched files...">&1
echo "Fixing permissions for patched files...">&2
ui_print "Fixing permissions for patched files..."
exe echo "Fixing permissions for patched files..."

# Copy system
# cp -rLf system/. /system
chmod 550 /system/bin/logd
chmod 755 /system/etc/init.d
chmod 644 /system/vendor/lib/libsecure_storage.so
chmod 644 /system/vendor/lib64/libsecure_storage.so
chmod 755 /system/xbin


