# -----------------------------------
# TS KERNEL INSTALLER for ported roms
#
# Anykernel2 created by @osm0sis
# Everything else done by @djb77
# Modded by ThundeRStormS Team
# -----------------------------------

## AnyKernel setup
properties() {
kernel.string=
do.devicecheck=1
do.modules=0
do.cleanup=1
do.cleanuponabort=1
device.name1=herolte
device.name2=hero2lte
device.name3=
device.name4=
device.name5=
}

# Shell Variables
block=/dev/block/platform/155a0000.ufs/by-name/BOOT
ramdisk=/tmp/anykernel/ramdisk
split_img=/tmp/anykernel/split_img
patch=/tmp/anykernel/patch
is_slot_device=0
ramdisk_compression=auto
TEMP=/tmp/anykernel

# Extra 0's needed for CPU Freqs
ZEROS=000

## AnyKernel methods (DO NOT CHANGE)
# import patching functions/variables - see for reference
. /tmp/anykernel/tools/ak2-core.sh

## AnyKernel install
ui_print "- Extracing Boot Image"
dump_boot

# Ramdisk changes - Set split_img OSLevel depending on ROM
(grep -w ro.build.version.security_patch | cut -d= -f2) </system/build.prop > /tmp/rom_oslevel
ROM_OSLEVEL=`cat /tmp/rom_oslevel`
echo $ROM_OSLEVEL | rev | cut -c4- | rev > /tmp/rom_oslevel
ROM_OSLEVEL=`cat /tmp/rom_oslevel`
ui_print "- Setting security patch level to $ROM_OSLEVEL"
echo $ROM_OSLEVEL > $split_img/boot.img-oslevel

# Ramdisk changes - Deodexed ROM
ui_print "- Patching for Deodexed ROM"
replace_string default.prop "pm.dexopt.first-boot=interpret-only" "pm.dexopt.first-boot=quicken" "pm.dexopt.first-boot=interpret-only"
replace_string default.prop "pm.dexopt.boot=verify-profile" "pm.dexopt.boot=verify" "pm.dexopt.boot=verify-profile"
replace_string default.prop "pm.dexopt.install=interpret-only" "pm.dexopt.install=quicken" "pm.dexopt.install=interpret-only"
cp -rf $patch/sepolicy/* $ramdisk
chmod 644 $ramdisk/sepolicy

## AnyKernel file attributes
# set permissions/ownership for included ramdisk files
chmod 644 $ramdisk/default.prop
chmod 755 $ramdisk/init.rc
chmod 755 $ramdisk/sbin/ts-kernel.sh
chown -R root:root $ramdisk/*

# End ramdisk changes
ui_print "- Writing Boot Image"
write_boot

## System Patches
# Remove unwatned McRegistry entry
rm -f /system/app/mcRegistry/ffffffffd00000000000000000000004.tlbin
# Clean Apex data
rm -rf /data/data/com.sec.android.app.apex
# Remove init.d Placeholder
# rm -f /system/etc/init.d/placeholder
# Delete Wakelock.sh 
rm -f /magisk/phh/su.d/wakelock*
rm -f /su/su.d/wakelock*
rm -f /system/su.d/wakelock*
rm -f /system/etc/init.d/wakelock*

## End install
ui_print "System Patched - Done"

